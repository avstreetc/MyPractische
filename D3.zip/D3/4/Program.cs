﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Не сделано, к сожалению! я не люблю математику");
